const COLLECTION ={
    customer:'customer',
    admin:"adminsignup",
    Product:"products",
    Category:"category",
    SubCategory:"subcategory",
    Upload:"upload",
    SubSubCategory:"subsubcategory",
    slider:"sliders",
    Notification:"notificationx",
    cart:"cart"
}
module.exports =COLLECTION;