const express = require('express');
const { AddCart, CartsAggregate, updateCart } = require('../controlls/CartController');
const CartRouter = express.Router()

CartRouter.post('/addcart',AddCart)
CartRouter.get('/getcart/:id',CartsAggregate)
CartRouter.put('/updateCart/:id',updateCart)
module.exports = CartRouter;